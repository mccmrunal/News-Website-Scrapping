import React from 'react'
import { connect } from 'react-redux'

function NewsBanner({news,bannerId,bannerClose}) {
  return (
   
    <div>
      <br/>
       <button type="button" onClick={()=>bannerClose()} className="btn btn-dark">Close Article</button>
      {news.map(item=>{
          if(item.publishedAt === bannerId ){
            return  <div key={item.publishedAt}>
                <br></br>
            <h1 style={{color:"white"}}>{item.title}</h1>
           <img className="profile-photo" style={{height:"50%",width:"70%"}} src={item.urlToImage} alt={"Carlie Anglemire"}/>
            <h4 style={{color:"white"}}>{item.content}</h4>
            <a type="button" className="btn btn-dark"  href={item.url} target="_blank">Click Here To Read Full Article Here</a>
          </div>
          }
      })}
      
    </div>
  )
}
const mapStateToProps = (state=>{
    return{
      news:state.news.newsPosts
  
    }
  })
export default connect(mapStateToProps)(NewsBanner)
