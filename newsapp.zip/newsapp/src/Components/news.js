import React, { useEffect, useState } from 'react'
import { connect } from 'react-redux'
import { fetchNewsTrigger,changeBannerState } from '../ReduxStore/NewsAction'
import NewsBanner from './NewsBanner';
import NewsCard from './NewsCard';
import '../App.css';
import './Box.css'

function News({news,newsFetch,fetchCountryNews,bannerState,loading}) {
  const [banner,setBanner] = useState(false);
  console.log(banner)
  const [bannerId,setBannerId] = useState("");

 const changeToBanner = (id)=>{
   setBanner(true);
   setBannerId(id);
 }
  
  useEffect(()=>{
    newsFetch();
  },[newsFetch])
  
  return (
    
    <div >
    {console.log(news)}
      <nav className="navbar navbar-expand-lg navbar navbar-dark bg-dark">
  <div className="container-fluid">
    <a className="navbar-brand" href="/">Home</a>
    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span className="navbar-toggler-icon"></span>
    </button>
    <div className="collapse navbar-collapse" id="navbarSupportedContent">
      <ul className="navbar-nav me-auto mb-2 mb-lg-0">
        <li className="nav-item">
          <h4 type="button" className="nav-link active" aria-current="page"onClick={()=>{fetchCountryNews("us")
                                                                               setBanner(false)} } href="/">USA NEWS</h4>
        </li>
        <li className="nav-item">
          <h4 className="nav-link active" aria-current="page"  onClick={()=>{fetchCountryNews("in")
                                                                               setBanner(false)}  } href="/">INDIA NEWS</h4>
        </li>
        <li className="nav-item">
          <h4 className="nav-link active" aria-current="page" onClick={()=>{fetchCountryNews("gb")
                                                                               setBanner(false)} } href="/">UK NEWS</h4>
        </li>
        
      </ul>
      <form className="d-flex">
        <input className="form-control me-2" type="search" placeholder="Search" aria-label="Search"/>
        <button className="btn btn-outline-success" type="submit">Search</button>
      </form>
    </div>
  </div>
      </nav>
     
     { banner?<NewsBanner bannerClose={()=>setBanner(false)} bannerId={bannerId}/>:
      (loading?<h1>Loading</h1>
        :<div className='grid'>
            {
              news.map(item=>
                <div className='grid' key={item.publishedAt}>
                  <div className="box1">
                  <NewsCard image={item.urlToImage} title={item.title} id={item.publishedAt} changeToBanner={changeToBanner}/>
                  </div> 
                  </div>
                  )
            }
        </div>)}
    </div>
  )
}

const mapStateToProps = (state=>{

  return{
    news:state.news.newsPosts,
    bannerState:state.news.banner,
    loading:state.news.loading

  }
})



const mapDispatchToProps = (dispatch=>{
  return{
    newsFetch:()=>dispatch(fetchNewsTrigger()),
    fetchCountryNews:(country,e)=>dispatch(fetchNewsTrigger(country,e)),
    changeBannerState:()=>dispatch(changeBannerState())


  }
})

export default connect(mapStateToProps,mapDispatchToProps)(News)
