import React from 'react'
import { connect } from 'react-redux'
import { fetchNewsTrigger } from '../ReduxStore/NewsAction'


function NewsCard({image,title,id,changeToBanner}) {
 
  return (
      <div>
      <div className="card box" style={{width: 350}}>
    <img src={image} className="card-img-top" alt="https://s29937.pcdn.co/wp-content/uploads/2012/11/FailedStamp.jpg"/>
    <div className="card-body">
      <h5 className="card-title">{title}</h5>
      <h4 href="/" className="btn btn-primary" onClick={()=>changeToBanner(id)}>Click to Read More...</h4>
    </div>
    </div>
    </div>

    
  )
}
const mapStateToProps = (state=>{
  return{
    news:state.news.newsPosts

  }
})

const mapDispatchToProps = (dispatch=>{
  return{
    newsFetch:()=>dispatch(fetchNewsTrigger())

  }
})

export default connect(mapStateToProps,mapDispatchToProps)(NewsCard)
