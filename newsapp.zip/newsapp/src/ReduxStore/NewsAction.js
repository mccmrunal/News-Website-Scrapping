import { FETCH_FAILED, FETCH_SUCCESS, NEWS_COUNTRY } from "./NewsTypes";
import { FETCH_NEWS,NEWS_EXPAND,BANNER_STATE } from "./NewsTypes";
import axios from "axios";

export const fetchNews=()=>{
    return{
        type:FETCH_NEWS
    }
} 
export const fetchSuccess=(news)=>{
    return{
        type:FETCH_SUCCESS,
        payload:news
    }
} 
export const fetchFail=(error)=>{
    return{
        type:FETCH_FAILED,
        payload:error
    }
} 
export const newsCountry=(country)=>{

    return{
        type:NEWS_COUNTRY,
        payload:country
    }
} 
export const newsExpand=(id)=>{
    return{
        type:NEWS_EXPAND,
        payload:id
    }
} 
export const changeBannerState=(id)=>{
    return{
        type:BANNER_STATE,
        
    }
}

export const fetchNewsTrigger = (country="us")=>{
    return((dispatch)=>{
            dispatch(fetchNews)
            axios.get(`https://newsapi.org/v2/top-headlines?country=${country}&apiKey=cd29fa5c7ff14a098ad7bfe360d777f8
            `)
            .then(response=>
                {   
                    dispatch(fetchSuccess(response.data.articles))
                }
            )
        })
    
}