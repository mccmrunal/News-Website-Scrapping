import { FETCH_FAILED, FETCH_SUCCESS } from "./NewsTypes";
import { FETCH_NEWS,BANNER_STATE } from "./NewsTypes";

const initialState={
    loading:true,
    newsPosts:{},
    error:'',
    banner:false
}

const newsReducer = (state=initialState,action)=>{
    switch(action.type){
        case FETCH_NEWS:
            return{
                ...state,loading:true,banner:false
            }
        case FETCH_SUCCESS:
            return{
                ...state,loading:false,newsPosts:action.payload,
            }
         case FETCH_FAILED:
            return{
                ...state,loading:false,newsPosts:""
            }
        case BANNER_STATE:return{
            ...state,banner:false
        }
        default:return state
    }
}
export default newsReducer