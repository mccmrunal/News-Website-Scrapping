import newsReducer from "./NewsReducer";
import { combineReducers } from "redux";

const rootReducer = combineReducers({
    news:newsReducer,
})

export default rootReducer;